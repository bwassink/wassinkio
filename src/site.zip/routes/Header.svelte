<header>
  <div class="title"><a href="/">Wassink.io</a></div>
  <nav><a href="/">Home</a> | <a href="blog">Blog</a> | <a href="quiz">Quiz</a> | <a href="fandoms">Fandoms</a> | <a href="js30">JS30</a></nav>
</header>