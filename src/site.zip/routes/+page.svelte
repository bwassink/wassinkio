<main>
<h1>Welcome to my work in progress!</h1>
<p>This is a site where I mess around and try to gain more of an understanding of development.</p>
<p>Thanks for visiting! Go try your hand at some <a href="/quiz">Trivia</a>!</p>
</main>
