<main>
  <slot />
</main>