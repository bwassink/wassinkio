<footer>
  <p>Wassink.io</p>
</footer>