import {defineCliConfig} from 'sanity/cli'

export default defineCliConfig({
  api: {
    projectId: 'i87qtavt',
    dataset: 'production'
  }
})
